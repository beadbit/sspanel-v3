<?php

namespace App\Models;

class Config extends Model
{
    protected $connection = "default";
    protected $table = 'config';
}
