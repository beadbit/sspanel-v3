---
name: Bug report
about: Bug 反馈

---

1.此项目为前端，不解决任何后端对接相关问题

2.issues 是反馈 bug / 提供建议的，不是提供技术支持的

3.请先去 https://demo.nimaqu.com 进行测试，并写明如何复现这个问题

4.请在面板路径下运行`git show HEAD`，然后在 issue 中贴上输出内容，如果是页面问题（500 或 Slim Application Error )，请在 config 开启 debug 模式后截图或贴出输出内容，以便定位问题

5.请确认已阅读完 wiki 和此 issue 模板，并删除以上内容后发送，否则我们不会回复您的 issue 并加入黑名单
